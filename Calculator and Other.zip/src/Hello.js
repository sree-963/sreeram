import React from 'react'
import Firebase from './Firebase'

const Hello = () => {
  return (
    <div>Hello <Firebase/></div>
  )
}

export default Hello