import React,{useContext} from 'react'
import {store} from './App'
const Count = () => {
    const [data,setData]=useContext(store)
  return (
    <div className='card'><div className='card-body'> <b>Products Count:</b> <b>{data.length}</b></div></div>
  )
}

export default Count