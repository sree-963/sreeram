// import React from 'react'
// import { BrowserRouter, Route, Routes } from 'react-router-dom'
// import Home from './Home'
// import Editform from './Editform'

// const App = () => {
//   return (
//     <>
//       <BrowserRouter>
//         <Routes>
//           <Route path="/" element={<Home/>} />
//           <Route path="/Editform" element ={<Editform />} />
//         </Routes>
//       </BrowserRouter>
//     </>
//   )
// }

// export default App

// import React,{createContext,useState} from 'react'
// import ComponentA from './ComponentA'
// import ComponentB from './ComponentB'
//  export const store = createContext(); 
// const App = () => {
//   const [data,setData]=useState(0)
//   return (
//     <store.Provider value={[data,setData]}>
//     <center>
//       <ComponentA /> 
//       <ComponentB />, <br/>
//       <button onClick={()=>setData(data+2)}>ADD</button>
//     </center>
//     </store.Provider> 
//   )
// }

// export default App
import React,{createContext,useState} from 'react'

// import Display from './Display'
// import Countprd from './Countprd'
 import Calculator from './Calculator';



export const store = createContext(); 
const App = () => {
     const [data,setData]=useState([
    {
  bn:"Vivo X70 Pro"
},
{
  bn:"Vivo V23 Pro"
},
{
  bn:"Vivo V21"
},
{
  bn:"Vivo X60"
},
{
  bn:"Vivo X50"
}

 ])
    return (
      <>
  
      {/* <store.Provider value={[data,setData]}>
      <center>
      <Countprd />
        <Display /> 
      <br/>
       
       </center>
       </store.Provider>  */}
       <Calculator/>
       </>
     )
     
   }
  

export default App