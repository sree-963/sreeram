import React,{useContext, useState} from 'react'

import {store} from './App'
const Display = () => {
    const [data,setData]=useContext(store)
    const [name,setName]=useState('')
    const submitHandler=e=>{ 
        e.preventDefault()
        setData([...data, {bn:name}])
    }
  return (
    <div className='card'><div className='card-body'><u><b>PRODUCTS:</b></u> <strong> {data.map(item=> <ul type='disc'><li>{item.bn}</li></ul>)}</strong></div>
    <form className='form' onSubmit={submitHandler}>                

<input type='text' placeholder='Enter the brandname'onChange={(e)=>setName(e.target.value)} />
<input type='submit' value='ADD'/>
    </form>
    </div>
    
  )
}

   


export default Display