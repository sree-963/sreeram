import React,{useState} from 'react'
import './Cal.css'
const Calculator = () => {
    const [result,setResult ]=useState(" ");
    const handlerClick=(e)=>{
        setResult(result.concat(e.target.name));
    }
    const clear= ()=>{
setResult(' ');
    }
    const backspace= ()=>{
setResult(result.slice(0,-1))
    }
    const res=(e)=>{
        try{
            setResult(eval(result).toString())
        }catch(err){
            setResult('Error')
        }
        
    }
  return (
      <>
    <div className='container'>
        <form>
            <input type='text' value={result}/>
        </form>
<div className='key'>
    <button className="light"onClick={clear} id='clear'>Clear</button>
    <button className="light"onClick={backspace} id='backspace'>C</button>
    <button name="7" onClick={ handlerClick}>7</button>
    <button name="8" onClick={ handlerClick}>8</button>
    <button name="9" onClick={ handlerClick}>9</button>
    <button className="light" name="/" onClick={ handlerClick}>&divide;</button>
    <button className="light" name="*" onClick={ handlerClick}>&times;</button>
    <button name="4" onClick={ handlerClick}>4</button>
    <button name="5" onClick={ handlerClick}>5</button>
    <button name="6" onClick={ handlerClick}>6</button>
    <button className="light" name="-" onClick={ handlerClick}>&ndash;</button>
    <button className="light"name="+" onClick={ handlerClick}>+</button>
    <button name="1" onClick={ handlerClick}>1</button>
    <button name="2" onClick={ handlerClick}>2</button>
    <button name="3" onClick={ handlerClick}>3</button>
    <button className="light" name="." onClick={ handlerClick}>.</button>
    <button className="light" name="%" onClick={ handlerClick}>%</button>
    <button className="light" onClick={res} id="result">=</button>
    <button name="0" onClick={ handlerClick}>0</button>
    
    <button className="light" name='+/-'onClick={ handlerClick}>+/-</button>
</div>

    </div>
    </>
  )
}

export default Calculator