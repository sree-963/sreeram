import Firebase from './Firebase';
const firebaseConfig = {
    apiKey: "AIzaSyCxRk_87JOyODN8jpueGiTl7mPTttySRPc",
    authDomain: "textapi-a58e0.firebaseapp.com",
    projectId: "textapi-a58e0",
    storageBucket: "textapi-a58e0.appspot.com",
    messagingSenderId: "278461532188",
    appId: "1:278461532188:web:f4e59db572f27565f5b7d9"
  };
  
  // Initialize Firebase
let FirebaseDB=Firebase.initializeApp(firebaseConfig);
 export default FirebaseDB.database().ref(); 