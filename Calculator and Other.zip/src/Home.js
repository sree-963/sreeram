import React,{useState} from 'react'
import FirebaseDB from './Firebase';
  const Home = () => {
  let mystyle={
    fontSize:"30px",
  }
  const [data,setData]=useState({
    firstname:" ",
    lastname:" ",
    email:" "
  })
  const {firstname,lastname,email}={data}
  const changeHandler= e =>{
     setData({...data,[e.target.name]:e.target.value});
   }
   const submitHandler= e =>{
    e.preventDefault(); 
    
    FirebaseDB.child('registration').push(
      data,
      err =>{ if (err){
         console.log(err); 
        }
      }
    )
  }
  return (
    <>
  
      <center><h1><u><b><mark>Registration Form</mark></b></u></h1></center>    
  <center><form className='form-horizontal'onSubmit={submitHandler}>
          
 <label style={mystyle} ><b>FirstName:</b> </label>
 <input type="text"className="form-control"id='ra' name="firstname" value={firstname} onChange={changeHandler} />
 <label style={mystyle}><b>LastName:</b></label>
<input type="text" className="form-control" id='ra'name="lastname" value={lastname} onChange={changeHandler}/> 
 <label style={mystyle}><b>Email:</b></label>
<input type="email"className="form-control"id='ra' name="email" value={email} onChange={changeHandler}/>
 <input type="submit"className="btn btn-success"style={{
   width:'100px',height:'40px',fontSize:'20px', marginTop:"6px"}}value="SUBMIT"></input>
         
   </form></center>
    </>
  )
}

 export default Home;