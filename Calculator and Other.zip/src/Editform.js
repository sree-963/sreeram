import React from 'react'


const Editform = () => {
  let mystyle={
    fontSize:"30px",
  }
  return (
    <>
    
      <center><h1><u><b><mark>Edit Form</mark></b></u></h1></center>
      <center>
        <form className='form-horizontal' autoComplete='off'>
          
            <label style={mystyle} ><b>FirstName:</b> </label>
         <input type="text"className="form-control"id='ra'placeholder="Enter Your FirstName." name="FirstName" ></input>
            <label style={mystyle}><b>LastName:</b></label>
            <input type="text" className="form-control" id='ra'placeholder="Enter Your LastName."name="LastName"></input> 
           <label style={mystyle}><b>Email:</b></label>
            <input type="email"className="form-control"id='ra'placeholder=" Enter Your Email." name="Email" ></input>
            <input type="submit"className="btn btn-success"style={{
width:'100px',height:'40px',fontSize:'20px', marginTop:"6px"}}value="SUBMIT"></input>
         
        </form>
      </center>
    </>
  )
}

export default Editform;
